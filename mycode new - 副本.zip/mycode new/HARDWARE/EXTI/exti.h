#ifndef __EXTI_H
#define __EXIT_H	 
#include "sys.h"
						    
extern char status;
void EXTIX_Init(void);//IO��ʼ��
		 					    
#endif

