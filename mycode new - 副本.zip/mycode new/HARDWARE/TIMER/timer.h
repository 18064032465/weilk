#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
extern u32 clock; 


void TIM3_Int_Init(u16 arr,u16 psc); 

#define  state2_site   14
#define  state1_site   14
#define  delt          20
#define  state3_site   28

 
#endif
