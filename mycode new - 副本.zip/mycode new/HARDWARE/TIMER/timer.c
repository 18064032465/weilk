#include "timer.h"
#include "led.h"
#include "tcs34725.h"
#include "GETCOLOR.h"
 
 
 
 
 
 
 extern int rgb_v[3],hsl_v[3];
 extern int init_flag;
 
u32 clock;
int mode_flag=0,state_flag=0,site=0,site1=0,site2=0,stop_count=100,flag,flag1,site1;
int flag_rgb[3]={50,50,50},rgb1[3][7],rgb2[3][7],rgb3[3][7],j,print_flag;


//ͨ�ö�ʱ���жϳ�ʼ��
//����ʱ��ѡ��ΪAPB1��2������APB1Ϊ36M
//arr���Զ���װֵ��
//psc��ʱ��Ԥ��Ƶ��
//����ʹ�õ��Ƕ�ʱ��3!
void TIM3_Int_Init(u16 arr,u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
		GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //ʱ��ʹ��
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO,ENABLE);  //ʹ��GPIO����ʱ��ʹ��
//	GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4; //TIM2_CH3
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
//	
//	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ2
//	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //�Ƚ����ʹ��
//	TIM_OCInitStructure.TIM_Pulse = 500; //���ô�װ�벶��ȽϼĴ���������ֵ
//	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //�������:TIM����Ƚϼ��Ը�
//	TIM_OC1Init(TIM3, &TIM_OCInitStructure);  //����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIMx
//	


//  TIM_CtrlPWMOutputs(TIM3,ENABLE);	
//	
//	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);  

//	TIM_TimeBaseStructure.TIM_Period = arr; //��������һ�������¼�װ�����Զ���װ�ؼĴ������ڵ�ֵ	 ������5000Ϊ500ms
//	TIM_TimeBaseStructure.TIM_Prescaler =psc; //����������ΪTIMxʱ��Ƶ�ʳ�����Ԥ��Ƶֵ  10Khz�ļ���Ƶ��  
//	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //����ʱ�ӷָ�:TDTS = Tck_tim
//	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM���ϼ���ģʽ
//	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
// 

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);
	
	//???TIM3
	TIM_TimeBaseStructure.TIM_Period = arr; //???????????????????????????
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //??????TIMx??????????? 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //??????:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM??????
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //??TIM_TimeBaseInitStruct?????????TIMx???????
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; //TIM_CH2
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;  //??????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);//???GPIO
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; //???????:TIM????????2
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //??????
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //????:TIM???????
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);  //??T??????????TIM3 OC2
	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);  //??TIM3?CCR2????????
	TIM_Cmd(TIM3, ENABLE);  //??TIM3
	
	TIM_SetCompare2(TIM3,0);   //??pwm  ??? = 450/arr
	
	
	TIM_ITConfig(  //ʹ�ܻ���ʧ��ָ����TIM�ж�
		TIM3, 
		TIM_IT_Update ,
		ENABLE  //ʹ��
		);
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  //TIM3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  //��ռ���ȼ�0��
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  //�����ȼ�3��
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQͨ����ʹ��
	NVIC_Init(&NVIC_InitStructure);  //����NVIC_InitStruct��ָ���Ĳ�����ʼ������NVIC�Ĵ���

	TIM_Cmd(TIM3, ENABLE);  //ʹ��TIMx����
							 
}

void TIM3_IRQHandler(void)   //TIM3�ж� 100ms  һ��
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) //���ָ����TIM�жϷ������:TIM �ж�Դ 
		{
			if(init_flag==2)
			{				
				test(44);
			}
			if(init_flag==1)
			{
				static int i=0;
			  get_color();
				if(mode_flag==1)
				{
					TIM_SetCompare2(TIM3,500);
				}
					
				else if(mode_flag==2)
				{
		   
					if(state_flag==0)
					{
					TIM_SetCompare2(TIM3,500);						
					if((rgb_v[0]<=(flag_rgb[0]+delt)&&rgb_v[0]>=(flag_rgb[0]-delt))&&(rgb_v[1]<=(flag_rgb[1]+delt)&&rgb_v[0]>=(flag_rgb[0]-delt))&&(rgb_v[1]<=(flag_rgb[1]+delt)&&rgb_v[0]>=(flag_rgb[0]-delt)))
					{
						state_flag=1;
						TIM_SetCompare2(TIM3,0);	
						stop_count--;
					}
				}
					if(state_flag==1)
					{
						stop_count--;
					  if(stop_count==0)
					  {
						stop_count=100;
						state_flag=2;
						site=0;
							
					  }
				 }
					if(state_flag==2)
					{
						if(flag1==0)
						{
							if(site<=state2_site)
								{
							    TIM_SetCompare2(TIM3,500);
							    site++;
						    }
								else
								{
						      TIM_SetCompare2(TIM3,0);
									flag1=1;
								}
						}
					 if(flag1==1)
					{
						if(stop_count!=0)
						{
							site1=0;
							if(j==0)
							{
						  rgb1[0][i]+=rgb_v[0];
						  rgb1[1][i]+=rgb_v[1];
						  rgb1[2][i]+=rgb_v[2];
							}
							else if(j==1)
				      {
						  rgb2[0][i]+=rgb_v[0];
						  rgb2[1][i]+=rgb_v[1];
						  rgb2[2][i]+=rgb_v[2];
							}
							else if(j==2)
							{
						  rgb3[0][i]+=rgb_v[0];
						  rgb3[1][i]+=rgb_v[1];
						  rgb3[2][i]+=rgb_v[2];
							}
						  stop_count--;
						}
						else 
						{
							
						  stop_count=100;
							if(j==0)
							{
							rgb1[0][i]/=stop_count;
							rgb1[1][i]/=stop_count;
							rgb1[2][i]/=stop_count;
							}
							else if(j==1)
				      {
							rgb2[0][i]/=stop_count;
							rgb2[1][i]/=stop_count;
							rgb2[2][i]/=stop_count;
							}
							else if(j==2)
							{
							rgb3[0][i]/=stop_count;
							rgb3[1][i]/=stop_count;
							rgb3[2][i]/=stop_count;
							}
							i++;
							flag1=0;
							site=0;
						}
//						if(flag1==2)
//						{
//						    if(site1<state1_site&&flag1==2)
//						  {
//								TIM_SetCompare2(TIM3,500);
//								
//						  }
//					  }
					}
				}
						{
						if(i==7)
						{
					    if(site2<state3_site)
						  {
								TIM_SetCompare2(TIM3,500);
								site2++;
								state_flag=3;
						  }
							else if(site2==state3_site)
							{
								TIM_SetCompare2(TIM3,0);
							state_flag=2;
							flag1=0;
								site2=0;
							j++;
							i=0;
							}
						}
					}
				}
				
				if(j==3)
				{
					mode_flag=0;
					print_flag=1;
				}
			}
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);  //���TIMx���жϴ�����λ:TIM �ж�Դ 

		}
}












