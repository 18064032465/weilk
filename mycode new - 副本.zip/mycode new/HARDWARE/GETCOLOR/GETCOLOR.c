#include "GETCOLOR.h"
#include "tcs34725.h"



int rgb_v[3],hsl_v[3];

extern COLOR_RGBC rgb;
extern COLOR_HSL  hsl;

void get_color(void)
{
	TCS34725_GetRawData(&rgb); 
	RGBtoHSL(&rgb,&hsl);
	rgb_v[0]=rgb.r;
	rgb_v[1]=rgb.g;
	rgb_v[2]=rgb.b;
	hsl_v[0]=hsl.h;
	hsl_v[1]=hsl.s;
	hsl_v[2]=hsl.l;

}

void freq(int f)
{
	TIM_Cmd(TIM3,DISABLE);
	TIM_ARRPreloadConfig(TIM3,DISABLE);
	TIM3->ARR=f;
	TIM_ARRPreloadConfig(TIM3,ENABLE);
	TIM_Cmd(TIM3,ENABLE);
	
}


void test(int round)
{
	static int i=0;
	if(i<round)
	TIM_SetCompare2(TIM3,500);
	else
	TIM_SetCompare2(TIM3,0);
  if(i<10000)
	i++;
		
}
