#ifndef __GETCOLOR_H
#define __GETCOLOR_H
#include "sys.h"

void get_color(void);
void freq(int f);
void test(int round);

#endif
