#ifndef __STEOMOTOR_H
#define __STEOMOTOR_H
#include "sys.h"
extern int step_conter;
void TIM2_PWM_Init(u16 arr,u16 psc);
void stepmoter_init(void);
#endif
